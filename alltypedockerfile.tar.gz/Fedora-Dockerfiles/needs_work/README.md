Do not place anything else in this directory.  4/2/2014.

Please just update the wiki page and we will just work through the normal PR process for any other suggested Dockerfiles.

https://github.com/scollier/Fedora-Dockerfiles/wiki/Fedora-Dockerfiles-ToDo


