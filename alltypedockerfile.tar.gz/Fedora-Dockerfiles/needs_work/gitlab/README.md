dockerfiles-fedora-bind
========================

Fedora dockerfile for GitLab (https://github.com/gitlabhq)

Tested on Docker 0.8.1

Still under development
