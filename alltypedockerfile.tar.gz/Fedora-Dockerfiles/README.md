Fedora-Dockerfiles
==================

This is the upstream source for the [fedora-dockerfiles](http://koji.fedoraproject.org/koji/packageinfo?packageID=18023) package.  To get started with Docker on Fedora:

```
# sudo yum install docker-io fedora-dockerfiles
```

Some [guidelines](https://github.com/scollier/Fedora-Dockerfiles/wiki/Guidelines-for-Creating-Dockerfiles) for contributing to this repo.

We welcome contributions.
